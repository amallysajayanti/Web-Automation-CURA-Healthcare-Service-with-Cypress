describe('template spec', () => {

  it('Logs in and books an appointment', () => {
    //visit website
    cy.visit('https://katalon-demo-cura.herokuapp.com/') //masuk website

    //Initiate the appointment
    cy.get('#btn-make-appointment').click();
    
    //Login
      cy.get('#txt-username').type('John Doe');
      cy.get('#txt-password').type('ThisIsNotAPassword');
      cy.get('#btn-login').click();
    
    //Make an Appointment
    cy.get('#combo_facility').select('Seoul CURA Healthcare Center');
    cy.get('#chk_hospotal_readmission').check();
    cy.get('#radio_program_medicaid').check();
    cy.get('#txt_comment').type('This is a test appointment');
    cy.get('#txt_visit_date').click();
    cy.get('.datepicker-days .day:not(.old):not(.new):first').click();
    cy.get('#btn-book-appointment').click();

    //Verify the Appointment
    cy.contains('Appointment Confirmation').should('be.visible');

  })

  Cypress.on('uncaught:exception', (err,runnable) => {
    return false
  })



})